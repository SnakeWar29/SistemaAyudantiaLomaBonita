-- MariaDB dump 10.19  Distrib 10.4.22-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ayudantia
-- ------------------------------------------------------
-- Server version	10.4.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_citizen_fees`
--

DROP TABLE IF EXISTS `account_citizen_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_citizen_fees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `year_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `citizen_id` int(11) DEFAULT NULL,
  `fee_category_id` int(11) DEFAULT NULL,
  `date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_citizen_fees`
--

LOCK TABLES `account_citizen_fees` WRITE;
/*!40000 ALTER TABLE `account_citizen_fees` DISABLE KEYS */;
INSERT INTO `account_citizen_fees` VALUES (1,3,7,5,1,'2023-10',340,'2023-10-19 03:47:33','2023-10-19 03:47:33'),(2,3,1,9,2,'2023-10',450,'2023-10-19 03:50:52','2023-10-19 03:50:52'),(3,3,7,5,2,'2023-10',680,'2023-10-19 03:57:21','2023-10-19 03:57:21'),(5,5,5,18,2,'2023-11',570,'2023-11-08 04:11:39','2023-11-08 04:11:39'),(6,5,5,32,2,'2023-11',540,'2023-11-08 04:11:39','2023-11-08 04:11:39');
/*!40000 ALTER TABLE `account_citizen_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_employee_salaries`
--

DROP TABLE IF EXISTS `account_employee_salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_employee_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL COMMENT 'user_id',
  `date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_employee_salaries`
--

LOCK TABLES `account_employee_salaries` WRITE;
/*!40000 ALTER TABLE `account_employee_salaries` DISABLE KEYS */;
INSERT INTO `account_employee_salaries` VALUES (7,14,'2023-10',4350,'2023-10-19 23:41:22','2023-10-19 23:41:22'),(10,15,'2023-11',2500,'2023-11-08 23:53:17','2023-11-08 23:53:17'),(11,36,'2023-11',1450,'2023-11-08 23:53:17','2023-11-08 23:53:17');
/*!40000 ALTER TABLE `account_employee_salaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_other_costs`
--

DROP TABLE IF EXISTS `account_other_costs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_other_costs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_other_costs`
--

LOCK TABLES `account_other_costs` WRITE;
/*!40000 ALTER TABLE `account_other_costs` DISABLE KEYS */;
INSERT INTO `account_other_costs` VALUES (3,'2023-10-18',250,'Papel Bond Blanco Carta Paquete de 500 Hojas, el papel de la impresora esta por agotarse','20231019205058954.jfif','2023-10-20 02:23:07','2023-10-20 02:50:50'),(4,'2023-10-20',500,'Reparaciones a los baños','202310201913mantenimiento-auto-mecanico-motor-e1539967150648.jpeg','2023-10-21 01:13:01','2023-10-21 01:13:01');
/*!40000 ALTER TABLE `account_other_costs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assign_citizens`
--

DROP TABLE IF EXISTS `assign_citizens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assign_citizens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `citizen_id` int(11) NOT NULL COMMENT 'user_id=citizen_id',
  `roll` int(11) DEFAULT NULL,
  `class_id` int(11) NOT NULL,
  `year_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assign_citizens`
--

LOCK TABLES `assign_citizens` WRITE;
/*!40000 ALTER TABLE `assign_citizens` DISABLE KEYS */;
INSERT INTO `assign_citizens` VALUES (2,4,NULL,1,5,2,4,'2023-09-26 03:47:40','2023-09-26 03:47:40'),(3,5,1,7,3,3,5,'2023-09-26 03:52:19','2023-10-07 23:05:44'),(4,8,NULL,6,5,4,5,'2023-09-27 20:32:49','2023-10-07 23:08:59'),(5,9,1,1,3,2,4,'2023-09-28 21:33:09','2023-10-06 00:41:56'),(6,10,2,1,4,3,4,'2023-09-28 21:34:43','2023-10-06 00:43:03'),(8,18,NULL,5,5,2,3,'2023-10-24 20:47:29','2023-10-24 20:47:29'),(9,24,NULL,5,4,3,3,'2023-10-25 23:22:27','2023-10-25 23:22:27'),(10,25,13,7,5,2,5,'2023-10-26 02:17:40','2023-10-26 02:30:10'),(11,26,NULL,6,4,4,4,'2023-10-26 02:19:11','2023-10-26 02:19:11'),(12,27,NULL,7,4,3,4,'2023-10-26 02:20:49','2023-10-26 02:20:49'),(13,28,NULL,5,3,3,3,'2023-10-26 02:22:07','2023-10-26 02:22:07'),(14,29,NULL,6,3,4,4,'2023-10-26 02:24:04','2023-10-26 02:24:04'),(15,30,NULL,1,5,2,4,'2023-10-26 02:37:16','2023-10-26 02:37:16'),(16,31,NULL,5,5,3,4,'2023-10-26 02:39:41','2023-10-26 02:39:41'),(17,32,NULL,5,5,4,4,'2023-10-26 02:42:29','2023-10-26 02:42:29'),(18,33,NULL,6,4,3,4,'2023-10-26 02:43:58','2023-10-26 02:43:58'),(19,35,NULL,5,5,2,3,'2023-11-05 00:02:07','2023-11-08 00:44:42');
/*!40000 ALTER TABLE `assign_citizens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assign_supports`
--

DROP TABLE IF EXISTS `assign_supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assign_supports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `support_id` int(11) NOT NULL,
  `full_support` double NOT NULL,
  `monthly_support` double NOT NULL,
  `total_payments` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assign_supports`
--

LOCK TABLES `assign_supports` WRITE;
/*!40000 ALTER TABLE `assign_supports` DISABLE KEYS */;
INSERT INTO `assign_supports` VALUES (19,6,2,1000,1,10,'2023-09-21 07:58:33','2023-09-21 07:58:33'),(20,6,3,2000,2,20,'2023-09-21 07:58:33','2023-09-21 07:58:33'),(21,6,4,3000,3,30222,'2023-09-21 07:58:33','2023-09-21 07:58:33'),(27,5,2,20000,2000,20,'2023-10-10 22:42:12','2023-10-10 22:42:12'),(28,5,3,20001,2001,21,'2023-10-10 22:42:12','2023-10-10 22:42:12'),(29,5,4,20002,2000,10,'2023-10-10 22:42:12','2023-10-10 22:42:12'),(30,7,2,3000,3,1000,'2023-10-17 01:00:18','2023-10-17 01:00:18'),(34,1,2,2000,500,4,'2023-11-06 03:20:46','2023-11-06 03:20:46'),(35,1,3,5000,1000,5,'2023-11-06 03:20:46','2023-11-06 03:20:46'),(36,1,4,3000,1000,3,'2023-11-06 03:20:46','2023-11-06 03:20:46');
/*!40000 ALTER TABLE `assign_supports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badge_types`
--

DROP TABLE IF EXISTS `badge_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badge_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `badge_types_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badge_types`
--

LOCK TABLES `badge_types` WRITE;
/*!40000 ALTER TABLE `badge_types` DISABLE KEYS */;
INSERT INTO `badge_types` VALUES (2,'Dólar estadounidense (USD)','2023-09-19 07:11:33','2023-09-19 07:11:33'),(6,'Peso mexicano (MXN)','2023-09-21 01:15:37','2023-09-21 01:15:37');
/*!40000 ALTER TABLE `badge_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citizen_classes`
--

DROP TABLE IF EXISTS `citizen_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizen_classes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `citizen_classes_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizen_classes`
--

LOCK TABLES `citizen_classes` WRITE;
/*!40000 ALTER TABLE `citizen_classes` DISABLE KEYS */;
INSERT INTO `citizen_classes` VALUES (1,'Participativo','2023-09-06 13:05:40','2023-10-19 03:51:58'),(5,'Pasivo','2023-09-17 02:08:57','2023-10-19 03:52:09'),(6,'Inactivo','2023-09-17 02:09:03','2023-10-19 03:52:38'),(7,'Clase cuatro','2023-09-21 04:56:35','2023-09-21 04:56:35');
/*!40000 ALTER TABLE `citizen_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citizen_groups`
--

DROP TABLE IF EXISTS `citizen_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizen_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `citizen_groups_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizen_groups`
--

LOCK TABLES `citizen_groups` WRITE;
/*!40000 ALTER TABLE `citizen_groups` DISABLE KEYS */;
INSERT INTO `citizen_groups` VALUES (2,'Grupo A','2023-09-13 04:22:10','2023-10-19 03:53:00'),(3,'Grupo B','2023-09-23 03:35:07','2023-10-19 03:53:04'),(4,'Grupo C','2023-09-23 03:35:17','2023-10-19 03:53:09');
/*!40000 ALTER TABLE `citizen_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citizen_shifts`
--

DROP TABLE IF EXISTS `citizen_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizen_shifts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `citizen_shifts_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizen_shifts`
--

LOCK TABLES `citizen_shifts` WRITE;
/*!40000 ALTER TABLE `citizen_shifts` DISABLE KEYS */;
INSERT INTO `citizen_shifts` VALUES (3,'Diurna','2023-09-23 03:36:28','2023-09-23 03:36:28'),(4,'Nocturna','2023-09-23 03:36:36','2023-09-23 03:36:36'),(5,'Mixta','2023-09-23 03:36:45','2023-09-23 03:36:45');
/*!40000 ALTER TABLE `citizen_shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citizen_supports`
--

DROP TABLE IF EXISTS `citizen_supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizen_supports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `citizen_id` int(11) NOT NULL COMMENT 'user_id',
  `id_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `assign_support_id` int(11) DEFAULT NULL,
  `marks` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizen_supports`
--

LOCK TABLES `citizen_supports` WRITE;
/*!40000 ALTER TABLE `citizen_supports` DISABLE KEYS */;
INSERT INTO `citizen_supports` VALUES (1,10,'undefined',4,1,24,10000,'2023-10-17 02:36:12','2023-10-17 02:36:12'),(4,5,'undefined',3,7,30,5002,'2023-10-18 23:52:53','2023-10-18 23:52:53'),(8,9,'undefined',3,1,34,1000,'2023-11-06 03:32:51','2023-11-06 03:32:51');
/*!40000 ALTER TABLE `citizen_supports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citizen_years`
--

DROP TABLE IF EXISTS `citizen_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizen_years` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `citizen_years_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizen_years`
--

LOCK TABLES `citizen_years` WRITE;
/*!40000 ALTER TABLE `citizen_years` DISABLE KEYS */;
INSERT INTO `citizen_years` VALUES (3,'2023','2023-09-13 01:24:44','2023-09-13 01:24:44'),(4,'2022','2023-09-23 03:34:55','2023-09-23 03:34:55'),(5,'2021','2023-09-23 03:35:00','2023-09-23 03:35:00');
/*!40000 ALTER TABLE `citizen_years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `designations`
--

DROP TABLE IF EXISTS `designations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `designations_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `designations`
--

LOCK TABLES `designations` WRITE;
/*!40000 ALTER TABLE `designations` DISABLE KEYS */;
INSERT INTO `designations` VALUES (4,'Técnico Informatico','2023-10-11 01:11:10','2023-10-11 01:11:10'),(5,'Asistente','2023-10-11 01:11:22','2023-10-11 01:11:22'),(6,'Encargado de Limpieza','2023-10-11 01:11:29','2023-10-11 01:11:29');
/*!40000 ALTER TABLE `designations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_citizens`
--

DROP TABLE IF EXISTS `discount_citizens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount_citizens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `assign_citizens_id` int(11) NOT NULL,
  `fee_category_id` int(11) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_citizens`
--

LOCK TABLES `discount_citizens` WRITE;
/*!40000 ALTER TABLE `discount_citizens` DISABLE KEYS */;
INSERT INTO `discount_citizens` VALUES (1,2,1,15,'2023-09-26 03:47:40','2023-09-26 03:47:40'),(2,3,1,15,'2023-09-26 03:52:19','2023-09-29 02:46:51'),(3,4,1,15,'2023-09-27 20:32:49','2023-09-27 20:32:49'),(4,5,1,10,'2023-09-28 21:33:09','2023-09-28 21:33:09'),(5,6,1,5,'2023-09-28 21:34:43','2023-09-28 21:34:43'),(6,7,1,5,'2023-10-01 00:48:12','2023-10-01 00:48:12'),(7,8,1,5,'2023-10-24 20:47:29','2023-10-24 20:47:29'),(8,9,1,10,'2023-10-25 23:22:27','2023-10-25 23:22:27'),(9,10,1,10,'2023-10-26 02:17:40','2023-11-09 00:03:14'),(10,11,1,10,'2023-10-26 02:19:11','2023-10-26 02:19:11'),(11,12,1,10,'2023-10-26 02:20:49','2023-10-26 02:20:49'),(12,13,1,10,'2023-10-26 02:22:07','2023-10-26 02:22:07'),(13,14,1,10,'2023-10-26 02:24:04','2023-10-26 02:24:04'),(14,15,1,10,'2023-10-26 02:37:16','2023-10-26 02:37:16'),(15,16,1,5,'2023-10-26 02:39:41','2023-10-26 02:39:41'),(16,17,1,10,'2023-10-26 02:42:29','2023-10-26 02:42:29'),(17,18,1,15,'2023-10-26 02:43:58','2023-10-26 02:43:58'),(18,19,1,50,'2023-11-05 00:02:07','2023-11-05 00:02:07'),(19,20,1,25,'2023-11-06 22:34:51','2023-11-06 22:34:51');
/*!40000 ALTER TABLE `discount_citizens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_attendances`
--

DROP TABLE IF EXISTS `employee_attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_attendances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL COMMENT 'user_id',
  `date` date NOT NULL,
  `attend_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_attendances`
--

LOCK TABLES `employee_attendances` WRITE;
/*!40000 ALTER TABLE `employee_attendances` DISABLE KEYS */;
INSERT INTO `employee_attendances` VALUES (73,14,'2023-10-14','Presente','2023-10-14 15:30:45','2023-10-14 15:30:45'),(74,15,'2023-10-14','Presente','2023-10-14 15:30:45','2023-10-14 15:30:45'),(75,16,'2023-10-14','Justificado','2023-10-14 15:30:45','2023-10-14 15:30:45'),(76,17,'2023-10-14','Ausente','2023-10-14 15:30:45','2023-10-14 15:30:45'),(77,14,'2023-10-13','Presente','2023-10-14 15:32:34','2023-10-14 15:32:34'),(78,15,'2023-10-13','Ausente','2023-10-14 15:32:34','2023-10-14 15:32:34'),(79,16,'2023-10-13','Justificado','2023-10-14 15:32:34','2023-10-14 15:32:34'),(80,17,'2023-10-13','Ausente','2023-10-14 15:32:34','2023-10-14 15:32:34'),(81,14,'2023-10-16','Ausente','2023-10-16 21:18:51','2023-10-16 21:18:51'),(82,15,'2023-10-16','Presente','2023-10-16 21:18:51','2023-10-16 21:18:51'),(83,16,'2023-10-16','Presente','2023-10-16 21:18:51','2023-10-16 21:18:51'),(84,17,'2023-10-16','Presente','2023-10-16 21:18:51','2023-10-16 21:18:51'),(89,14,'2023-10-18','Presente','2023-10-18 22:51:51','2023-10-18 22:51:51'),(90,15,'2023-10-18','Ausente','2023-10-18 22:51:51','2023-10-18 22:51:51'),(91,16,'2023-10-18','Presente','2023-10-18 22:51:51','2023-10-18 22:51:51'),(92,17,'2023-10-18','Presente','2023-10-18 22:51:51','2023-10-18 22:51:51'),(97,14,'2023-10-22','Justificado','2023-10-23 01:58:25','2023-10-23 01:58:25'),(98,15,'2023-10-22','Presente','2023-10-23 01:58:25','2023-10-23 01:58:25'),(99,16,'2023-10-22','Presente','2023-10-23 01:58:25','2023-10-23 01:58:25'),(100,17,'2023-10-22','Presente','2023-10-23 01:58:25','2023-10-23 01:58:25'),(101,14,'2023-10-25','Presente','2023-10-25 08:51:10','2023-10-25 08:51:10'),(102,15,'2023-10-25','Presente','2023-10-25 08:51:10','2023-10-25 08:51:10'),(103,16,'2023-10-25','Presente','2023-10-25 08:51:10','2023-10-25 08:51:10'),(104,17,'2023-10-25','Ausente','2023-10-25 08:51:10','2023-10-25 08:51:10'),(105,14,'2023-10-26','Presente','2023-10-27 02:28:42','2023-10-27 02:28:42'),(106,15,'2023-10-26','Presente','2023-10-27 02:28:42','2023-10-27 02:28:42'),(107,16,'2023-10-26','Presente','2023-10-27 02:28:42','2023-10-27 02:28:42'),(108,17,'2023-10-26','Ausente','2023-10-27 02:28:42','2023-10-27 02:28:42'),(139,14,'2023-11-07','Presente','2023-11-08 04:34:03','2023-11-08 04:34:03'),(140,15,'2023-11-07','Presente','2023-11-08 04:34:03','2023-11-08 04:34:03'),(141,16,'2023-11-07','Justificado','2023-11-08 04:34:03','2023-11-08 04:34:03'),(142,17,'2023-11-07','Ausente','2023-11-08 04:34:03','2023-11-08 04:34:03'),(143,36,'2023-11-07','Ausente','2023-11-08 04:34:03','2023-11-08 04:34:03');
/*!40000 ALTER TABLE `employee_attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_leaves`
--

DROP TABLE IF EXISTS `employee_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_leaves` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL COMMENT 'userid',
  `leave_purpose_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_leaves`
--

LOCK TABLES `employee_leaves` WRITE;
/*!40000 ALTER TABLE `employee_leaves` DISABLE KEYS */;
INSERT INTO `employee_leaves` VALUES (1,14,3,'2023-10-12','2023-11-12','2023-10-13 07:12:37','2023-10-13 07:50:30');
/*!40000 ALTER TABLE `employee_leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_sallary_logs`
--

DROP TABLE IF EXISTS `employee_sallary_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_sallary_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL COMMENT 'user_id',
  `previous_salary` int(11) DEFAULT NULL,
  `present_salary` int(11) DEFAULT NULL,
  `increment_salary` int(11) DEFAULT NULL,
  `effected_salary` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_sallary_logs`
--

LOCK TABLES `employee_sallary_logs` WRITE;
/*!40000 ALTER TABLE `employee_sallary_logs` DISABLE KEYS */;
INSERT INTO `employee_sallary_logs` VALUES (1,14,3000,3000,0,'2023-10-10','2023-10-11 08:38:51','2023-10-11 08:38:51'),(2,15,1500,1500,0,'2023-10-10','2023-10-11 08:48:46','2023-10-11 08:48:46'),(3,16,3000,3000,0,'2023-10-10','2023-10-11 08:58:52','2023-10-11 08:58:52'),(4,17,5000,5000,0,'2023-10-10','2023-10-11 09:07:36','2023-10-11 09:07:36'),(5,14,3000,4000,1000,'2023-10-11','2023-10-12 07:16:55','2023-10-12 07:16:55'),(6,16,3000,4000,1000,'2023-10-11','2023-10-12 07:19:07','2023-10-12 07:19:07'),(7,15,1500,2000,500,'2023-10-11','2023-10-12 07:23:16','2023-10-12 07:23:16'),(8,14,4000,4500,500,'2023-10-11','2023-10-12 07:25:16','2023-10-12 07:25:16'),(9,15,2000,2500,500,'2023-10-19','2023-10-19 23:02:34','2023-10-19 23:02:34'),(10,36,2000,2000,0,'2023-11-04','2023-11-06 01:18:12','2023-11-06 01:18:12'),(13,36,2000,1500,-500,'2023-11-08','2023-11-08 23:52:26','2023-11-08 23:52:26');
/*!40000 ALTER TABLE `employee_sallary_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_categories`
--

DROP TABLE IF EXISTS `fee_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fee_categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_categories`
--

LOCK TABLES `fee_categories` WRITE;
/*!40000 ALTER TABLE `fee_categories` DISABLE KEYS */;
INSERT INTO `fee_categories` VALUES (1,'Tarifa de registro','2023-09-15 06:20:44','2023-10-07 22:49:05'),(2,'Tarifa Mensual','2023-09-17 01:58:19','2023-10-08 05:01:47');
/*!40000 ALTER TABLE `fee_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_category_amounts`
--

DROP TABLE IF EXISTS `fee_category_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee_category_amounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fee_category_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_category_amounts`
--

LOCK TABLES `fee_category_amounts` WRITE;
/*!40000 ALTER TABLE `fee_category_amounts` DISABLE KEYS */;
INSERT INTO `fee_category_amounts` VALUES (34,2,1,500,'2023-10-10 22:33:04','2023-10-10 22:33:04'),(35,2,5,600,'2023-10-10 22:33:04','2023-10-10 22:33:04'),(36,2,6,700,'2023-10-10 22:33:04','2023-10-10 22:33:04'),(37,2,7,800,'2023-10-10 22:33:04','2023-10-10 22:33:04'),(39,1,1,100,'2023-11-06 03:13:51','2023-11-06 03:13:51'),(40,1,5,200,'2023-11-06 03:13:51','2023-11-06 03:13:51'),(41,1,6,300,'2023-11-06 03:13:51','2023-11-06 03:13:51'),(42,1,7,400,'2023-11-06 03:13:51','2023-11-06 03:13:51');
/*!40000 ALTER TABLE `fee_category_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_purposes`
--

DROP TABLE IF EXISTS `leave_purposes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_purposes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leave_purposes_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_purposes`
--

LOCK TABLES `leave_purposes` WRITE;
/*!40000 ALTER TABLE `leave_purposes` DISABLE KEYS */;
INSERT INTO `leave_purposes` VALUES (1,'Problemas familiares',NULL,NULL),(2,'Problemas personales ',NULL,NULL),(3,'Problemas de salud',NULL,NULL),(4,'Problemas ambientales',NULL,NULL),(5,'Operación de riñon','2023-10-13 07:12:37','2023-10-13 07:12:37');
/*!40000 ALTER TABLE `leave_purposes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (2,'2014_10_12_100000_create_password_resets_table',1),(3,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2023_07_15_195821_create_sessions_table',1),(8,'2023_09_06_051814_create_citizen_classes_table',3),(9,'2023_09_12_173707_create_citizen_years_table',4),(10,'2023_09_12_205119_create_citizen_groups_table',5),(11,'2023_09_13_223549_create_citizen_shifts_table',6),(12,'2023_09_14_234049_create_fee_categories_table',7),(13,'2023_09_16_191200_create_fee_category_amounts_table',8),(14,'2023_09_18_235318_create_badge_types_table',9),(15,'2023_09_20_185210_create_support_types_table',10),(16,'2023_09_20_200529_create_assign_supports_table',11),(17,'2023_09_22_063215_create_designations_table',12),(18,'2014_10_12_000000_create_users_table',13),(19,'2023_09_22_180004_create_assign_citizens_table',14),(20,'2023_09_22_182150_create_discount_citizens_table',14),(21,'2023_10_10_192136_create_employee_sallary_logs_table',15),(22,'2023_10_12_050539_create_leave_purposes_table',16),(23,'2023_10_12_050859_create_employee_leaves_table',16),(24,'2023_10_13_061839_create_employee_attendances_table',17),(25,'2023_10_16_165618_create_citizen_supports_table',18),(26,'2023_10_18_162902_create_supports_grades_table',19),(27,'2023_10_18_180314_create_account_citizen_fees_table',20),(28,'2023_10_19_052227_create_account_employee_salaries_table',21),(29,'2023_10_19_191342_create_account_other_costs_table',22),(30,'2023_10_25_005626_create_notifications_table',23);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('gsmo200715@upemor.edu.mx','$2y$10$QzebIMgDREjUHhWGjgKBOO81kUamYwlGu1Tdj1P1LzE9hBX.hwAh2','2023-10-24 01:11:49'),('Misszelda94@gmail.com','$2y$10$zjkuhCjfl7DHTRHpT/E5reaSXOxSJohcuJaMmWdcI7/zMWAUyYGky','2023-10-24 02:38:03'),('aajo201214@upemor.edu.mx','$2y$10$./9ID5cxr9la/YUQ/jHxS.PFOqv9qV9Cvv19aQstFYf/dR/uzzZ3W','2023-11-04 08:34:36');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('cn0nKKQWXu7kZPT8gKYqr7pM0AvwVl4rO3QyVa6Q',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiY3pRUXhVSEZsbXV4c2dxekVzajZlYmlqREtuZXM2WDhWY2pKMklDdyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCRnWFlKaC4uTlhHV05CaFdlLzlad3RPSTV0Um8yOGtHbTZ1cXFWbXlWZkRMVWJtbGdlYkNJZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kYXRhYmFzZS9kYXRhYmFzZS9pbXBvcnQvdmlldyI7fX0=',1699471512);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_types`
--

DROP TABLE IF EXISTS `support_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `support_types_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_types`
--

LOCK TABLES `support_types` WRITE;
/*!40000 ALTER TABLE `support_types` DISABLE KEYS */;
INSERT INTO `support_types` VALUES (2,'Pensión para personas de tercera edad','2023-09-21 01:15:48','2023-10-17 01:22:38'),(3,'Apoyo para personas con algún tipo de discapacidad','2023-09-21 04:50:27','2023-10-17 01:23:30'),(4,'Apoyo para padres o madres solteros(a)','2023-09-21 07:07:46','2023-10-17 01:23:54');
/*!40000 ALTER TABLE `support_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usertype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Empleado - Ciudadano',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Disabilities` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Admin - Encargado - Visualizador',
  `join_date` date DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `salary` double DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0=inactivo, 1=active',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','Jahir Antunez Antonio','aajo201214@upemor.edu.mx',NULL,'$2y$10$gXYJh..NXGWNBhWe/9ZwtOI5tRo28kGm6uqqVmyVfDLUbmlgebCIe','7771234567','Calle Fictisia #45','Masculino','202311071835channels4_profile (1).jpg',NULL,NULL,NULL,NULL,NULL,NULL,'Admin',NULL,NULL,NULL,1,'ufQj3xaG8jHiKh4PJ6SWVQl1F6p78lMwgKbBpU3FGookWNKarx9zoXV1K72C',NULL,NULL,NULL,'2023-11-08 00:35:09'),(2,'Admin','Luis Manzanares','luis_manzanares@gmail.com',NULL,'$2y$10$QdmXeD1kM7J5NBJdiwSUmOJVdGMtT4UEBomk8X9Q8AESBuQNanTfu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1524','Admin',NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-09-23 01:12:26','2023-10-11 02:12:00'),(4,'Ciudadano','Isabella María',NULL,NULL,'$2y$10$sfrAxJy/dIQZnE4Aymt86OGXXk10qNUEgFlD3nhAXBj4zt8l8yvae','7771234567','Calle Fictisia #12','Masculino','202310252025voluntaria-pixabay.jpeg','Manuel Medel Castro','Martha Medrazo Ferero','No aplica','20210001','2002-11-18','7659',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-09-26 03:47:40','2023-10-26 02:25:38'),(5,'Ciudadano','Manuel Castro Medel',NULL,NULL,'$2y$10$79f12RE4U4FcZ7w1NkPHPum1yqWrOG3CWkcPg79E7k/lfe1PdC3Xi','7771234561','Articulo 128 #58','Masculino','2023092521527153b1c64a3a6de9b15754eadae4427e.jpg','Alejandro Garcia Solis','Martha Medrazo Ferrero','Visual','20220005','2000-11-19','2686',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-09-26 03:52:19','2023-09-29 02:46:51'),(7,'Admin','Miguel Galicia','gsmo200715@upemor.edu.mx',NULL,'$2y$10$AnU/sGLS7P3W8bgwpIfOouA2qsVvxnkPP9Xs7p4Yr9n80vmPGFJSe','777123423','Calle falsa #12','Masculino','202310270037depositphotos_220729086-stock-photo-smiling-handsome-adult-man-looking.jpg',NULL,NULL,NULL,NULL,NULL,'4189','Encargado',NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-09-26 03:57:10','2023-10-27 06:37:10'),(8,'Ciudadano','Carla Fernanda Vargas',NULL,NULL,'$2y$10$V5yqONISgyixnvWyts5IFeVAUI8ApvN0xoQjW0lHvT6fvfPd8N2ES','7772164106','Calle Imaginaria #456, Colonia Irreal, Ciudad Ficticia','Femenino','202310252027images (1).jfif','Laura Martínez Ruiz','Martha Medrazo Fronteras','No aplica','20210006','2000-11-18','4749',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-09-27 20:32:49','2023-10-26 02:27:55'),(9,'Ciudadano','Elizabeth Rojas',NULL,NULL,'$2y$10$gsIbcI4NqsaRHuPMdboeXeMVNmBEXt3ZsJRkEnq9s../aSaivJbEm','7772384231','Calle 1','Femenino','202309281533perfil-mujer-vivo.png','Nombre 2','Nombre 1','No aplica','20230009','2000-11-23','2914',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-09-28 21:33:09','2023-09-28 21:33:09'),(10,'Ciudadano','Fernando Antunez',NULL,NULL,'$2y$10$DL7uSGs3zihCdWK/wFoQa.0uFX47QEsVsibK5D952pOcr3aio6qk2','7776815485','Calle fictisia 10','Masculino','202309301849images.jfif','Alejandro Garcia','Martha Medrazo','Visual','20220010','2000-06-24','672',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-09-28 21:34:43','2023-10-01 00:49:37'),(14,'Empleado','Ana Rodríguez Antúnez',NULL,NULL,'$2y$10$45Z68agXdqtNXO64M63Yc.49ifVsY/mHOChaQktP4KMiSnB26DHjy','7771234518','Calle Primavera #123, Colonia Flores del Valle, Ciudad Loma','Femenino','202310110644381005410_325643593341624_370412885711993914_n.jpg','Laura Martínez Galicia','Carlos Pérez Manzanares','Visual','2023100001','1990-07-16','4453',NULL,'2023-10-10',5,4500,1,NULL,NULL,NULL,'2023-10-11 08:38:51','2023-10-12 07:25:16'),(15,'Empleado','Javier Gómez Sánchez',NULL,NULL,'$2y$10$fFXYC9jEAxU8HAIDwIVWfe6c3w3jOGFfTPbcsAcpTJiAtvIo9W91m','7775551234','Calle Rosas #321, Colonia El Bosque, Ciudad Irreal','Masculino','202310110248Perfil-hombre-básico_738242395.jpg','Isabella Mendoza Ortiz','Daniel Jiménez Ramírez','Visual','2023100015','2000-11-20','6992',NULL,'2023-10-10',6,2500,1,NULL,NULL,NULL,'2023-10-11 08:48:46','2023-10-19 23:02:34'),(16,'Empleado','Sofía González Flores',NULL,NULL,'$2y$10$1jqzvDSaczu1HEc282SUs.RwQxS1j3vdmTjSCrkEYqrQzka4MNPEq','7777771111','Calle Acacias #987, Colonia Primavera, Ciudad Fictivia','Femenino','202310110258Sin título.jpg','Adrián Vargas Martínez','Valentina Ramos Pérez','Auditiva','2023100016','2000-01-04','9785',NULL,'2023-10-10',5,4000,1,NULL,NULL,NULL,'2023-10-11 08:58:52','2023-10-12 07:19:07'),(17,'Empleado','Alejandro Soto Torres',NULL,NULL,'$2y$10$RrJx3uZCF1rMG018xH5I8e9shasu2bXd3oRMQXzST1FXXdT4GB3p.','7778882222','Calle Robles #432, Colonia Libertad, Ciudad Imaginaria','Masculino','202310110307reg-c3-a9-jean-page-attends-marvel-studios-black-panther-2-news-photo-1674819103.jpg','Camila Ortega Ríos','Rodrigo Méndez García','No aplica','2023100017','2000-02-10','6145',NULL,'2023-10-10',4,5000,1,NULL,NULL,NULL,'2023-10-11 09:07:36','2023-10-11 09:07:36'),(18,'Ciudadano','Maria Fernanda Antúnez',NULL,NULL,'$2y$10$ZSFP.HLMspYhElyTZmqKJOXmgdld64.1UwiAr9B44x/9jdmQsuPPS','7772341293','Articulo 128 #58','Femenino','202310252026images.jfif','Fernando Antunez','Manuel Castro','Visual','20210011','2010-06-22','564',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-24 20:47:29','2023-10-26 02:26:47'),(22,NULL,'Ariana Antonio Martinez','ari.antonio.martinez@gmail.com',NULL,'$2y$10$UuH40NeZMOf92uoq6mfN6epgBqH1XcSoazS/IyXbYWHQ7cQ1gizt.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-25 08:29:48','2023-10-25 08:29:48'),(24,'Ciudadano','Emiliano Palacios',NULL,NULL,'$2y$10$/gE3vKYx0EnqmpGYgJgtiegi3P2TmIWMPf9TAyEkBqQVG6xM/eMJW','7778459714','Calle fictisia #23','Masculino',NULL,'Jahir Antunez','Gerardo Fortuna','No aplica','20220019','2000-11-23','2946',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-25 23:22:27','2023-10-25 23:22:27'),(25,'Ciudadano','Luis Alberto Perez',NULL,NULL,'$2y$10$mOj9Smg/xbbxuSBrCiGFB.Dprb3PoP0c7vf7b13AnYvNsQEYkqZL.','7771234235','Calle Falsa #123, Colonia Imaginaria, Ciudad Ficticia','Masculino','202310252017Perfil-hombre-básico_738242395.jpg','Alejandro Garcia','Martha Medrazo','No aplica','20210025','1998-07-06','394',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:17:40','2023-10-26 02:17:40'),(26,'Ciudadano','Juan Carlos Gómez',NULL,NULL,'$2y$10$U5EOebBypo9bzyp20gCeNu71Iz7/Ri7CLb8oyy9R7iRaYUbOf9oBu','7772937242','Calle Imaginación #789, Colonia Irreal, Villa de los Deseos','Masculino','202310252019hombre-joven-barba-gafas-redondas_273609-6203.jpg','Alejandro Garcia','Carlos Pérez López','Auditiva','20220026','1997-06-11','501',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:19:11','2023-10-26 02:19:11'),(27,'Ciudadano','Laura Cecilia Delgado',NULL,NULL,'$2y$10$Zjnv7yXbbtBB4HJ70EbbIel/1rEv6AFtASw1dBP1CRTijhykgb9iW','7778927392','Calle de los Sueños #321, Colonia Irreal, Ciudad Fantasma','Femenino','202310252020mujertrabajo.jpg','Manuel Medel','Daniel Jiménez Ramírez','No aplica','20220027','1999-02-12','6586',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:20:49','2023-10-26 02:20:49'),(28,'Ciudadano','Alejandro José Soto Hernández',NULL,NULL,'$2y$10$WC4mlul7/KLGOwjuWTmcsu9J4amsQCwC8VCZLwxUp.SsSWqFNaNxa','7778237467','Avenida de la Imaginación #654, Barrio de los Deseos, Pueblo Ilusorio','Masculino','202310252022istockphoto-625444804-612x612.jpg','Isabella Mendoza Ortiz','Carlos Pérez López','No aplica','20230028','1998-03-09','6768',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:22:07','2023-10-26 02:22:07'),(29,'Ciudadano','Javier Antonio García',NULL,NULL,'$2y$10$MtV7nIP6wUKQypgNKIZ8P.rTftXJNA0w9X7yxo.sfgaVG3vGhhjh2','7772831287','Avenida de los Sueños #789, Barrio de las Ilusiones, Pueblo Fantástico','Masculino','2023102520245b8a0cf63440f-bpfull.jpg','Laura Martínez Ruiz','Martha Medrazo Fronteras','Visual','20230029','1993-02-12','4664',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:24:04','2023-10-26 02:24:04'),(30,'Ciudadano','Valeria Guadalupe Flores',NULL,NULL,'$2y$10$s.DXO3fJHzUPYPww1JIGWOSn4otuIm5KCb/C/2nWBqkKaRG605JGe','7771263271','Calle de los Sueños #789, Colonia Irreal, Ciudad Ficticia','Femenino','202310252037pexels-photo-2272853.jpeg','Manuel Medel','Martha Medrazo Fronteras','No aplica','20210030','1998-08-05','569',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:37:16','2023-10-26 02:37:16'),(31,'Ciudadano','Gabriela Alejandra Jimenez',NULL,NULL,'$2y$10$MlCi9zyJpkAUeL04f4BEZeEV6o1t08VNsFAfZ05bk/TNe5Pg3nOy6','7772137217','Avenida de la Imaginación #456, Barrio de las Ilusiones, Pueblo Fantástico','Femenino','202310252039xSummer-Hairstyles-300x300.jpg.pagespeed.gp+jp+pj+ws+js+rj+rp+ri+rm+cp+md+im=20.ic.v2rZqBcwrv.jpg','Laura Martínez Ruiz','Carlos Pérez López','No aplica','20210031','1997-11-06','9458',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:39:41','2023-10-26 02:39:41'),(32,'Ciudadano','Natalia Sofía Méndez',NULL,NULL,'$2y$10$gvHyufVRpzDGQTYbWjsJ9O6Iix8TNifKaoSTJEk5WtSTk5dMGF51e','7772631263','Calle Falsa #234, Colonia de los Deseos, Villa Imaginaria','Femenino','202310252042dd6fee56de51191687e69a010c83ce8e.jpg','Alejandro Garcia Solis','Daniel Jiménez Ramírez','Auditiva','20210032','1993-11-04','6408',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:42:29','2023-10-26 02:42:29'),(33,'Ciudadano','Regina Fernanda Torres',NULL,NULL,'$2y$10$YVKV9LJSWcIi59bChdu15.U.sNsxTeCm1Rd0hsIUtcqwMjvrvgZwW','7771273217','Calle de la Ilusión #123, Colonia de los Sueños, Pueblo de las Fantasías','Femenino','202310252043473b65ad992fbddd4c283e39edd6df0d.jpg','Isabella Mendoza Ortiz','Carlos Pérez López','No aplica','20220033','1997-10-09','9871',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-10-26 02:43:58','2023-10-26 02:43:58'),(35,'Ciudadano','Lorenzo Antonio',NULL,NULL,'$2y$10$OS2.5zrAvi.5svJboRg22e8UIgu3S.3SpgMYguHzZ9ONjDp2FA52u','7772643744','Calle Primavera #45','Masculino','202311041802Captura de pantalla 2023-11-04 120016.png','Ariana Antonio Martínez','Fernando Antúnez Román','No aplica','20210034','1980-06-28','4040',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-11-05 00:02:07','2023-11-08 00:39:53'),(36,'Empleado','Jose Daniel Galicia Hernandez',NULL,NULL,'$2y$10$loWkGehBh/J4kiHlIxarHuZmBjWuAAwK5g2VqPkRUNamUOiPsZCae','7772837283','Calle Nubes #45, Colonia Loma Bonita','Masculino','20231105191816529546243675.jpg','Luis Alberto Perez','Valeria Guadalupe Flores','No aplica','2023110018','1995-07-04','349',NULL,'2023-11-04',5,1500,1,NULL,NULL,NULL,'2023-11-06 01:18:12','2023-11-08 23:52:26'),(37,NULL,'Usuario prueba','usuarioprueba@gmail.com',NULL,'$2y$10$nttnDGvp.TVaYo1evTXWnOnuD8kFlusbQNY3.cZZRvm3htzdCyUOC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-11-06 06:37:47','2023-11-06 06:37:47'),(38,'Admin','Pepe Rodriguez Hernandez','snake.war2002@gmail.com',NULL,'$2y$10$qz71SXX9uvv7NWRz9pDosufLc1gQ2Qpman1hq9XrONxAhXFQHaWua',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'6242','Visualizador',NULL,NULL,NULL,1,NULL,NULL,NULL,'2023-11-06 22:09:35','2023-11-06 22:10:19');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 13:25:16
